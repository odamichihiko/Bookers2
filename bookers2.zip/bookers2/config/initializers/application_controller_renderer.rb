# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'd360116e0457d68fcdde19608ac8466b8fe4b1c930bb40639417fcaa0a904f584d8b47aaaf0b68e993d389a9f119bae5b8f3ed867c2f4250015682628f78216e'
