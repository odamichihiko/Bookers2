Rails.application.routes.draw do
  devise_for :users
  root to: 'homes#top'
  get  'home/about', to: 'homes#about'
  resources :books
  # post 'books' => 'books#create'
  get  'books' => 'books#index', as: 'index_booklist'
  # get  'books/:id' => 'books#show', as: 'booklist'
  # get  'books/:id/edit' => 'books#edit', as: 'edit_booklist'
  # patch 'books/:id' => 'books#update', as: 'update_booklist'
  # delete 'books/:id' => 'books#destroy', as: 'destroy_booklist'
  resources :users, only: [:index, :show, :edit, :update]
end
